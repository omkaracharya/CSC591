# Load the libraries 
# To install pcalg library you may first need to execute the following commands:
# source("https://bioconductor.org/biocLite.R")
# biocLite("graph")
# biocLite("RBGL")

# Read the input data 

# Build a VAR model 
# Select the lag order using the Schwarz Information Criterion with a maximum lag of 10
# see ?VARSelect to find the optimal number of lags and use it as input to VAR()

# Extract the residuals from the VAR model 
# see ?residuals

# Check for stationarity using the Augmented Dickey-Fuller test 
# see ?ur.df

# Check whether the variables follow a Gaussian distribution  
# see ?ks.test

# Write the residuals to a csv file to build causal graphs using Tetrad software


# OR Run the PC and LiNGAM algorithm in R as follows,
# see ?pc and ?LINGAM 

# PC Algorithm

# LiNGAM Algorithm
