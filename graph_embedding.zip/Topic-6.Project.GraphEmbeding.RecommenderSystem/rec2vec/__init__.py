__author__='Anatoli Melechko'
__email__='avmelech@ncsu.edu'
__version__='0.0.1'
